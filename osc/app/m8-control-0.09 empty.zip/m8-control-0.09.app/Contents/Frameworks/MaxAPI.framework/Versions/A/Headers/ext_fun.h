/*************************/
/* Copyright 1988 IRCAM. */
/*************************/

#ifndef _EXT_FUN_H_
#define _EXT_FUN_H_

 // structure definitions moved to ext_maxtypes.h
 
#endif /* _EXT_FUN_H_ */
